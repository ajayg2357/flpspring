package com.cg.service;

import java.util.List;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.Invoice;
import com.cg.dao.IinvoiceRepo;

@Service
public class InvoiceServiceImpl implements IinvoiceService {
	@Autowired
	IinvoiceRepo dao;

	static Scanner sc = new Scanner(System.in);

	@Override
	public Invoice createInvoice(Invoice obj) {

		double d = (obj.getProd_Price() * obj.getProd_Discount()) / 100;
		obj.setProd_ConPrice(d);

		double p = (obj.getProd_Price() * obj.getProd_Promo()) / 100;

		obj.setProd_Promo(p);

		double f = (obj.getProd_Tax() + d + p);

		obj.setProd_FinalPrice(f);

		return dao.save(obj);
	}

	@Override
	public void deleteInvoice(int id) {
		dao.deleteById(id);

	}

	@Override
	public List<Invoice> viewAllInvoice() {

		return dao.findAll();
	}

	@Override
	public Invoice findSingleInvoice(int id) {

		return dao.findById(id).get();
	}

}

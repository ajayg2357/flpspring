package com.cg.bean;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="invo13")

public class Invoice {
	

		@Id
		private int Prod_Id;

		private String Prod_Category;

		private String Prod_Type;

		private String Prod_Brand;

		private String Prod_Description;

		private double Prod_Price;

		private double Prod_Discount;

		private double Prod_ConPrice;

		private double Prod_Quantity;

		private double Prod_Promo;

		private double Prod_Tax;

		private double Prod_Deliverycharges;

		private double Prod_FinalPrice;

		public int getProd_Id() {
			return Prod_Id;
		}

		public void setProd_Id(int prod_Id) {
			this.Prod_Id = prod_Id;

		}

		public String getProd_Category() {
			return Prod_Category;
		}

		public void setProd_Category(String prod_Category) {
			this.Prod_Category = prod_Category;
		}

		public String getProd_Type() {
			return Prod_Type;
		}

		public void setProd_Type(String prod_Type) {
			this.Prod_Type = prod_Type;
		}

		public String getProd_Brand() {
			return Prod_Brand;
		}

		public void setProd_Brand(String prod_Brand) {
			this.Prod_Brand = prod_Brand;
		}

		public String getProd_Description() {
			return Prod_Description;
		}

		public void setProd_Description(String prod_Description) {
			this.Prod_Description = prod_Description;
		}

		public double getProd_Price() {
			return Prod_Price;
		}

		public void setProd_Price(double prod_Price) {
			this.Prod_Price = prod_Price;
		}

		public double getProd_Discount() {
			return Prod_Discount;
		}

		public void setProd_Discount(double prod_Discount) {
			this.Prod_Discount = prod_Discount;
		}

		public double getProd_ConPrice() {
			return Prod_ConPrice;
		}

		public void setProd_ConPrice(double prod_ConPrice) {
			this.Prod_ConPrice = prod_ConPrice;
		}

		public double getProd_Quantity() {
			return Prod_Quantity;
		}

		public void setProd_Quantity(double prod_Quantity) {
			this.Prod_Quantity = prod_Quantity;
		}

		public double getProd_Promo() {
			return Prod_Promo;
		}

		public void setProd_Promo(Double prod_Promo) {
			this.Prod_Promo = prod_Promo;
		}

		public double getProd_Tax() {
			return Prod_Tax;
		}

		public void setProd_Tax(double prod_Tax) {
			this.Prod_Tax = prod_Tax;
		}

		public double getProd_Deliverycharges() {
			return Prod_Deliverycharges;
		}

		public void setProd_Deliverycharges(double prod_Deliverycharges) {
			this.Prod_Deliverycharges = prod_Deliverycharges;
		}

		public double getProd_FinalPrice() {
			return Prod_FinalPrice;
		}

		public void setProd_FinalPrice(double prod_FinalPrice) {
			this.Prod_FinalPrice = prod_FinalPrice;
		}

		public Invoice() {
			super();
			// TODO Auto-generated constructor stub
		}
		
		

		public Invoice(int prod_Id, String prod_Category, String prod_Type, String prod_Brand, String prod_Description,
				double prod_Price, double prod_Discount, double prod_ConPrice, double prod_Quantity, Double prod_Promo,
				double prod_Tax, double prod_Deliverycharges, double prod_FinalPrice) {
			super();
			Prod_Id = prod_Id;
			Prod_Category = prod_Category;
			Prod_Type = prod_Type;
			Prod_Brand = prod_Brand;
			Prod_Description = prod_Description;
			Prod_Price = prod_Price;
			Prod_Discount = prod_Discount;
			Prod_ConPrice = prod_ConPrice;
			Prod_Quantity = prod_Quantity;
			Prod_Promo = prod_Promo;
			Prod_Tax = prod_Tax;
			Prod_Deliverycharges = prod_Deliverycharges;
			Prod_FinalPrice = prod_FinalPrice;
		}

		@Override
		public String toString() {
			return "Invoice [Prod_Id=" + Prod_Id + ", Prod_Category=" + Prod_Category + ", Prod_Type=" + Prod_Type
					+ ", Prod_Brand=" + Prod_Brand + ", Prod_Description=" + Prod_Description + ", Prod_Price="
					+ Prod_Price + ", Prod_Discount=" + Prod_Discount + ", Prod_ConPrice=" + Prod_ConPrice
					+ ", Prod_Quantity=" + Prod_Quantity + ", Prod_Promo=" + Prod_Promo + ", Prod_Tax=" + Prod_Tax
					+ ", Prod_Deliverycharges=" + Prod_Deliverycharges + ", Prod_FinalPrice=" + Prod_FinalPrice + "]";
		}

		}
